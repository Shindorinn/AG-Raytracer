# AG-Raytracer
Basic Raytracer implementation in C++ for Advanced Graphics on the UU

Git can be found at : https://github.com/aelex13/AG-Raytracer/

﻿#include "template.h"

Light::Light(vec3 position, vec3 color)
{
	this->position = position;
	this->color = color;
}
#pragma once

class Texture
{
public:


protected:

private:

};
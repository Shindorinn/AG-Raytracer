#pragma once
#include "template.h"

class Texture
{
};
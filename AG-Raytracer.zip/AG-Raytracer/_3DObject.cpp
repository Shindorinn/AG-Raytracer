#pragma once
#include "template.h"

class _3DObject
{
};
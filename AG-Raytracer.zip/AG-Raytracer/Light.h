﻿#pragma once

class Light
{
public:
	vec3 position;
	vec3 color;
	Light(vec3 position, vec3 color);
};
